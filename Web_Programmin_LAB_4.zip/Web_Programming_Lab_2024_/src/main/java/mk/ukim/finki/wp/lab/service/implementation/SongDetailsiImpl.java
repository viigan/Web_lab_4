package mk.ukim.finki.wp.lab.service.implementation;

import mk.ukim.finki.wp.lab.service.SongDetailsService;

public class SongDetailsiImpl implements SongDetailsService {
}
