package mk.ukim.finki.wp.lab.service;

public interface SongDetailsService {
}
